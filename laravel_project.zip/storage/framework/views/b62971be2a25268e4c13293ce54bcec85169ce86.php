<?php $__empty_1 = true; $__currentLoopData = $table_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<h1>Edit Employee : <?php echo e($row->employee_id); ?></h1>
	<form action="<?php echo e(url('/')); ?>/employee/<?php echo e($row->employee_id); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

    	<div>
    		<strong>Name : </strong>
    		<input type="text" name="name" value="<?php echo e($row->name); ?>" placeholder="name here..." >
    	</div>
    	<div>
    		<strong>Age : </strong>
    		<input type="number" name="age" value="<?php echo e($row->age); ?>" placeholder="age here..." >
    	</div>
    	<div>
    		<strong>Address : </strong>
    		<input type="text" name="address" value="<?php echo e($row->address); ?>" placeholder="address here..." >
    	</div>
    	<div>
    		<strong>Salary : </strong>
    		<input type="number" name="salary" value="<?php echo e($row->salary); ?>" placeholder="salary here..."  >
    	</div>
    	<div>
    		<strong>Position_id : </strong>
    		<input type="number" name="position_id" value="<?php echo e($row->position_id); ?>" placeholder="position_id here..." >
    	</div>
    	<div>
    		<strong>Position_id : </strong>
            <select name="position_id">
                <?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row_position->position_id); ?>"
						<?php echo e($row_position->position_id === $row->position_id ? "selected" : ""); ?>>
					<?php echo e($row_position->position_name); ?>

				</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    	</div>
		<div>
			<a href="<?php echo e(url('/')); ?>/employee">back</a>
			<button type="submit">Update</button>
		</div>
	</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<h1>This Employee id does not exist</h1>
<?php endif; ?>
