<h1>Create New Employee</h1>
<form action="<?php echo e(url('/')); ?>/employee" method="POST">
	<?php echo e(csrf_field()); ?>

	<?php echo e(method_field('POST')); ?>

	<div>
		<strong>Name : </strong>
		<input type="text" name="name" placeholder="name here..." >
	</div>
	<div>
		<strong>Age : </strong>
		<input type="number" name="age" placeholder="age here..." >
	</div>
	<div>
		<strong>Address : </strong>
		<input type="text" name="address" placeholder="address here..." >
	</div>
	<div>
		<strong>Salary : </strong>
		<input type="number" step="any" name="salary" placeholder="salary here..." >
	</div>
	<div>
		<strong>Position_id : </strong>
		<input type="number" step="step" name="position_id" placeholder="position_id here..." >
	</div>
	<div>
		<strong>Position_id : </strong>
        <select name="position_id">
            <?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($row_position->position_id); ?>"><?php echo e($row_position->position_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
	</div>
	<div>
		<a href="<?php echo e(url('/')); ?>/employee">back</a>
		<button type="submit">Create</button>
	</div>
</form>
