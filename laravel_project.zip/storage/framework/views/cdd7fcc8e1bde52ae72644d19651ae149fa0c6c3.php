<?php $__empty_1 = true; $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<h1>Position : <?php echo e($row->position_id); ?> </h1>
	<div>
		<strong>position_id : </strong>
		<span><?php echo e($row->position_id); ?></span>
	</div>
	<div>
		<strong>position_name : </strong>
		<span><?php echo e($row->position_name); ?></span>
	</div>
	<div>
		<a href="<?php echo e(url('/')); ?>/position">back to employee</a>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div>This Employee "id" does not exist</div>
<?php endif; ?>
