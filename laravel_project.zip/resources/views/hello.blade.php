<!-- View stored in resources/views/hello.blade.php -->
<html>
	<body>
		<h1>Hello World </h1>
	</body>
</html>
