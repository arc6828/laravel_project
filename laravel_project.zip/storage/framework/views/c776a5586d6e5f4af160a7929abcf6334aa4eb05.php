<?php $__empty_1 = true; $__currentLoopData = $table_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<h1>student : <?php echo e($row->student_id); ?> </h1>
	<div>
		<strong>name : </strong>
		<span><?php echo e($row->name); ?> </span>
	</div>
	<div>
		<strong>hours per week : </strong>
		<span><?php echo e($row->hours_per_week); ?></span>
	</div>
	<div>
		<strong>grade : </strong>
		<span><?php echo e($row->grade); ?></span>
	</div>	
	<div>
		<a href="<?php echo e(url('/')); ?>/student">back to student</a>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div>This student "id" does not exist</div>
<?php endif; ?>
