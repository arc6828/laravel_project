<h1>Employee List</h1>
<div>
	<a href="<?php echo e(url('/')); ?>/employee/create">New Employee</a>
</div>

<table border=1>
<tr>
		<th>employee_id</th>
		<th>name</th>
		<th>age</th>
		<th>address</th>
		<th>salary</th>
		<th>position_id</th>
		<th>position_name</th>
		<th>action</th>
	</tr>
	<?php $__currentLoopData = $table_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($row->employee_id); ?> </td>
		<td><?php echo e($row->name); ?> </td>
		<td><?php echo e($row->age); ?></td>
		<td><?php echo e($row->address); ?></td>
		<td><?php echo e($row->salary); ?></td>
		<td><?php echo e($row->position_id); ?></td>
		<td><?php echo e($row->position_name); ?></td>
		<td>
			<a href="<?php echo e(url('/')); ?>/employee/<?php echo e($row->employee_id); ?>">View</a>
			<a href="<?php echo e(url('/')); ?>/employee/<?php echo e($row->employee_id); ?>/edit">Edit</a>
			<a href="javascript:void(0)" onclick="onDelete( <?php echo e($row->employee_id); ?> )">Delete</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div style="display:none;">
	<form action="#" method="POST" id="form_delete" >
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('DELETE')); ?>

		<button type="submit">Delete</button>
	</form>
	<script>
		function onDelete(id){
			//--THIS FUNCTION IS USED FOR SUBMIT FORM BY script--//

			//GET FORM BY ID
			var form = document.getElementById("form_delete");
			//CHANGE ACTION TO SPECIFY ID
			form.action = "<?php echo e(url('/')); ?>/employee/"+id;
			//SUBMIT
			var want_to_delete = confirm('Are you sure to delete this employee?');
			if(want_to_delete){
				form.submit();
			}
		}
	</script>
</div>
<div>
	<img src="<?php echo e(url('/')); ?>/storage/avatar/25T3ZMtqvqW07Vy6aRyqHr0hunD5B8OKrfzbEHTJ.jpeg">
</div>
