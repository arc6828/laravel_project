<h1>Customer List</h1>
<div>
	<a href="<?php echo e(url('/')); ?>/customer/create">
        New Customer
    </a>
</div>

<table border=1>
<tr>
		<th>customer_id</th>
		<th>name</th>
		<th>age</th>
		<th>address</th>
		<th>salary</th>
		<th>position_id</th>
		<th>action</th>
	</tr>
	<?php $__currentLoopData = $table_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($row->customer_id); ?> </td>
		<td><?php echo e($row->name); ?> </td>
		<td><?php echo e($row->age); ?></td>
		<td><?php echo e($row->address); ?></td>
		<td><?php echo e($row->salary); ?></td>
		<td><?php echo e($row->position_id); ?></td>
		<td>
			<a href="<?php echo e(url('/')); ?>/customer/<?php echo e($row->customer_id); ?>">View</a>
			<a href="<?php echo e(url('/')); ?>/customer/<?php echo e($row->customer_id); ?>/edit">Edit</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
