<h1>Student List</h1>
<div>
	<a href="<?php echo e(url('/')); ?>/student/create">New Student</a>
</div>

<table border=1>
	<tr>
		<th>student_id</th>
		<th>name</th>
		<th>hour per week</th>
		<th>grade</th>
		<th>action</th>
	</tr>
	<?php $__currentLoopData = $table_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($row->student_id); ?> </td>
		<td><?php echo e($row->name); ?> </td>
		<td><?php echo e($row->hours_per_week); ?></td>
		<td><?php echo e($row->grade); ?></td>
		<td>
			<a href="<?php echo e(url('/')); ?>/student/<?php echo e($row->student_id); ?>">View</a>
			<a href="<?php echo e(url('/')); ?>/student/<?php echo e($row->student_id); ?>/edit">Edit</a>
			<a href="javascript:void(0)" onclick="onDelete( <?php echo e($row->student_id); ?> )">Delete</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<div style="display:none;">
	<form action="#" method="POST" id="form_delete" >
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('DELETE')); ?>

		<button type="submit">Delete</button>
	</form>
	<script>
		function onDelete(id){
			//--THIS FUNCTION IS USED FOR SUBMIT FORM BY script--//

			//GET FORM BY ID
			var form = document.getElementById("form_delete");
			//CHANGE ACTION TO SPECIFY ID
			form.action = "<?php echo e(url('/')); ?>/student/"+id;
			//SUBMIT
			var want_to_delete = confirm('Are you sure to delete this employee?');
			if(want_to_delete){
				form.submit();
			}
		}
	</script>
</div>
