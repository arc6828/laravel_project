<h1>Position List</h1>
<div>
	<a href="<?php echo e(url('/')); ?>/position/create">New Position</a>
</div>

<table border=1>
	<tr>
		<th>position_id</th>
		<th>position_name</th>
		<th>action</th>
	</tr>
	<?php $__currentLoopData = $table_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($row->position_id); ?></td>
		<td><?php echo e($row->position_name); ?></td>
		<td>
			<a href="<?php echo e(url('/')); ?>/position/<?php echo e($row->position_id); ?>">View</a>
			<a href="<?php echo e(url('/')); ?>/position/<?php echo e($row->position_id); ?>/edit">Edit</a>
			<a href="javascript:void(0)" onclick="onDelete( <?php echo e($row->position_id); ?> )">Delete</a>
		</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
