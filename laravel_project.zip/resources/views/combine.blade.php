<!-- View stored in resources/views/combine.blade.php -->
<html>
	<body>
		<h1>Hello, This is combine page : {{ $id }} </h1>
	</body>
</html>
