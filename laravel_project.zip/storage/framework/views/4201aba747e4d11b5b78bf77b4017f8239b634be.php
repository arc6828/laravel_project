<?php $__empty_1 = true; $__currentLoopData = $table_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<h1>Edit student : <?php echo e($row->student_id); ?></h1>
	<form action="<?php echo e(url('/')); ?>/student/<?php echo e($row->student_id); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		<div>
			<strong>name : </strong>
			<input type="text" name="name" value="<?php echo e($row->name); ?>" placeholder="name here..." >
		</div>
		<div>
			<strong>hours per week : </strong>
			<input type="number" name="hours_per_week" value="<?php echo e($row->hours_per_week); ?>" placeholder="hours_per_week here..." >
		</div>
		<div>
			<strong>grade : </strong>
			<input type="text" name="grade" value="<?php echo e($row->grade); ?>" placeholder="grade here..." >
		</div>
		<div>
			<a href="<?php echo e(url('/')); ?>/student">back</a>
			<button type="submit">Update</button>
		</div>
	</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<h1>This student id does not exist</h1>
<?php endif; ?>
