<style>
@font-face{
	font-family:  'THSarabunNew';
	font-style: normal;
	font-weight: normal;
	src: url("{{ asset('fonts/THSarabunNew.ttf') }}") format('truetype');
}
@font-face{
	font-family:  'THSarabunNew';
	font-style: normal;
	font-weight: normal;
	src: url("{{ asset('fonts/THSarabunNew Bold.ttf') }}") format('truetype');
}
@font-face{
	font-family:  'THSarabunNew';
	font-style: normal;
	font-weight: normal;
	src: url("{{ asset('fonts/THSarabunNew Italic.ttf') }}") format('truetype');
}
@font-face{
	font-family:  'THSarabunNew';
	font-style: normal;
	font-weight: normal;
	src: url("{{ asset('fonts/THSarabunNew BoldItalic.ttf') }}") format('truetype');
}
body{
	font-family: "THSarabunNew";
}
</style>

<div>สวัสดีวันจันทร์</div>
