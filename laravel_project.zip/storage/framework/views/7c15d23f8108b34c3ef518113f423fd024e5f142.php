<?php $__empty_1 = true; $__currentLoopData = $table_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<h1>Employee : <?php echo e($row->employee_id); ?> </h1>
	<div>
		<strong>name : </strong>
		<span><?php echo e($row->name); ?> </span>
	</div>
	<div>
		<strong>age : </strong>
		<span><?php echo e($row->age); ?></span>
	</div>
	<div>
		<strong>address : </strong>
		<span><?php echo e($row->address); ?></span>
	</div>
	<div>
		<strong>salary : </strong>
		<span><?php echo e($row->salary); ?></span>
	</div>
	<div>
		<strong>position_id : </strong>
		<span><?php echo e($row->position_id); ?></span>
	</div>
	<div style="display:none;">
		<strong>position_name : </strong>
		<span><?php echo e($row->position_name); ?></span>
	</div>
	<div>
		<a href="<?php echo e(url('/')); ?>/employee">back to employee</a>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div>This Employee "id" does not exist</div>
<?php endif; ?>
